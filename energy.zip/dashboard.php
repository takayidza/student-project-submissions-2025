<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>iot energy saver</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="assets/img/favicon.png" rel="icon">
  <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.gstatic.com" rel="preconnect">
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Nunito:300,300i,400,400i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.snow.css" rel="stylesheet">
  <link href="assets/vendor/quill/quill.bubble.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/simple-datatables/style.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

 <script src="states.js"></script>
  
</head>

<body>

<?php

include ("save_state.php");



?>

<script>
  let gled;
  let glcd;
  let gpump;
  let gfan;
</script>



  <!-- ======= Header ======= -->
  <header id="header" class="header fixed-top d-flex align-items-center">

    <div class="d-flex align-items-center justify-content-between">
      <a href="index.html" class="logo d-flex align-items-center">
        <img src="assets/img/logo.png" alt="">
        <span class="d-none d-lg-block">Energy Saver</span>
      </a>
      <i class="bi bi-list toggle-sidebar-btn"></i>
    </div><!-- End Logo -->

    <div class="search-bar">
      <form class="search-form d-flex align-items-center" method="POST" action="#">
        <input type="text" name="query" placeholder="Search" title="Enter search keyword">
        <button type="submit" title="Search"><i class="bi bi-search"></i></button>
      </form>
    </div><!-- End Search Bar -->

    <nav class="header-nav ms-auto">
      <ul class="d-flex align-items-center">

        <li class="nav-item d-block d-lg-none">
          <a class="nav-link nav-icon search-bar-toggle " href="#">
            <i class="bi bi-search"></i>
          </a>
        </li><!-- End Search Icon-->

        <li class="nav-item dropdown">

          <a class="nav-link nav-icon" href="#" data-bs-toggle="dropdown">
            <i class="bi bi-bell"></i>
            <span class="badge bg-primary badge-number">4</span>
          </a><!-- End Notification Icon -->

          <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow notifications">
            <li class="dropdown-header">
              You have 4 new notifications
              <a href="#"><span class="badge rounded-pill bg-primary p-2 ms-2">View all</span></a>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

         
            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="notification-item">
              <i class="bi bi-x-circle text-danger"></i>
              <div>
                <h4>Energy consumption alert</h4>
                <p>fridge used 20kw more than yesterdsy</p>
                <p>1 hr. ago</p>
              </div>
            </li>

            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="notification-item">
              <i class="bi bi-check-circle text-success"></i>
              <div>
                <h4>Energy Consumption alert</h4>
                <p>Water Tank is full</p>
                <p>2 hrs. ago</p>
              </div>
            </li>

            <li>
              <hr class="dropdown-divider">
            </li>

            <li class="notification-item">
              <i class="bi bi-info-circle text-primary"></i>
              <div>
                <h4>Energy Consumption alert</h4>
                <p>Lights are on and its already afternoon</p>
                <p>4 hrs. ago</p>
              </div>
            </li>

            <li>
              <hr class="dropdown-divider">
            </li>
            <li class="dropdown-footer">
              <a href="#">Show all notifications</a>
            </li>

          </ul><!-- End Notification Dropdown Items -->

        </li><!-- End Notification Nav -->

     <!-- End Messages Nav -->

        <li class="nav-item dropdown pe-3">

          <a class="nav-link nav-profile d-flex align-items-center pe-0" href="#" data-bs-toggle="dropdown">
            <div><i class="rounded-circle bi bi-person-fill"></i></div>
            <span class="d-none d-md-block dropdown-toggle ps-2">Nicole</span>
          </a><!-- End Profile Iamge Icon -->

          <ul class="dropdown-menu dropdown-menu-end dropdown-menu-arrow profile">
            <li class="dropdown-header">
              <h6></h6>
              <span>house owner</span>
            </li>
            <li>
              <hr class="dropdown-divider">
            </li>

          
            <li>
              <hr class="dropdown-divider">
            </li>

           
            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <hr class="dropdown-divider">
            </li>

            <li>
              <a class="dropdown-item d-flex align-items-center" href="index.html">
                <i class="bi bi-box-arrow-right"></i>
                <span>Sign Out</span>
              </a>
            </li>

          </ul><!-- End Profile Dropdown Items -->
        </li><!-- End Profile Nav -->

      </ul>
    </nav><!-- End Icons Navigation -->

  </header><!-- End Header -->

  <!-- ======= Sidebar ======= -->
  <aside id="sidebar" class="sidebar">

    <ul class="sidebar-nav" id="sidebar-nav">

      <li class="nav-item">
        <a class="nav-link " href="dashboard.php">
          <i class="bi bi-grid"></i>
          <span>Dashboard</span>
        </a>
      </li><!-- End Dashboard Nav -->

     

     


    
      

    </ul>

  </aside><!-- End Sidebar-->

  <main id="main" class="main">

    <div class="pagetitle">
      <h1>Dashboard</h1>
      <nav>
        <ol class="breadcrumb">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item active">Dashboard</li>
        </ol>
      </nav>
    </div><!-- End Page Title -->

    <section class="section dashboard">
      <div class="row">

        <!-- Left side columns -->
        <div class="col-lg-8">
          <div class="row">

            <!-- Wattage -->
            <div class="col-xxl-4 col-md-6">
              <div class="card info-card sales-card">

              

                <div class="card-body">
                  <h5 class="card-title">Wattage <span>| Today</span></h5>

                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-lightning-fill"></i>
                    </div>
                    <div class="ps-3">
                      <h6 id="watt">
                        
                        <script>
                           const baseUrl = `${window.location.protocol}//${window.location.hostname}/energy`;

fetch(`${baseUrl}/sensors.php`)

                          function calcW(v,lcd,led,pump,fan) {

                            let rounded = Number(lcd) * v + Number(led) * v + Number(pump) * v + Number(fan) * v;

                          

                            return  rounded.toFixed(2);
                            
                          }
                          function fetchTemperature() {
                              fetch(`${baseUrl}/sensors.php`)  // Adjust the path if necessary
                                  .then(response => response.json())
                                  .then(data => {
                                      if (data.temperature !== null) {

                                        glcd = data.lcd;
                                        gled = data.led;
                                       gpump =  data.pump;
                                       gfan = data.fan;
                                        
                  document.getElementById('watt').textContent =   calcW(3,data.water_level,data.lcd,data.led,data.pump,data.fan)  ;
                                      } else {
                                          document.getElementById('temperature').textContent = 'No data available';
                                      }
                                  })
                                  .catch(error => {
                                      console.error('Error fetching temperature:', error);
                                      document.getElementById('temperature').textContent = 'Error retrieving data';
                                  });
                          }
                      
                          // Fetch temperature every second (1000 ms)
                          setInterval(fetchTemperature, 1000);
                      
                          // Initial fetch on page load
                          fetchTemperature();
                      </script>
                        
                        
                        
                        
                        
                        
                        <code>kw</code></h6>
                      <span class="text-success small pt-1 fw-bold">12 kw</span> <span class="text-muted small pt-2 ps-1">increase</span>

                    </div>
                  </div>
                </div>

              </div>
            </div><!-- End Wattage -->

            <!--  Current card -->
            <div class="col-xxl-4 col-md-6">
              <div class="card info-card revenue-card">

               

                <div class="card-body">
                  <h5 class="card-title">Current <span> | Today</span> </h5>

                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                      <i class="bi bi-lightbulb"></i>
                    </div>
                    <div class="ps-3">
                      <h6 id = "current"> 
                        
                        
                        <script>
                          

                          function calcCurrent(lcd,led,pump,fan) {
                            let rounded = Number(lcd)  + Number(led) + Number(pump) + Number(fan) ;
                            return rounded.toFixed(2);
                            
                          }
                          function fetchTemperature() {
                              fetch(`${baseUrl}/sensors.php`)  // Adjust the path if necessary
                                  .then(response => response.json())
                                  .then(data => {
                                      if (data.temperature !== null) {
                                          document.getElementById('current').textContent = ` ${calcCurrent(data.water_level,data.lcd,data.led,data.pump,data.fan) } A`;
                                      } else {
                                          document.getElementById('temperature').textContent = 'No data available';
                                      }
                                  })
                                  .catch(error => {
                                      console.error('Error fetching temperature:', error);
                                      document.getElementById('temperature').textContent = 'Error retrieving data';
                                  });
                          }
                      
                          // Fetch temperature every second (1000 ms)
                          setInterval(fetchTemperature, 1000);
                      
                          // Initial fetch on page load
                          fetchTemperature();
                      </script>
                        
                        
                        
                        
                       </h6>
                      <span class="text-success small pt-1 fw-bold">8%</span> <span class="text-muted small pt-2 ps-1">increase</span>

                    </div>
                  </div>
                </div>

              </div>
            </div><!-- End  Current card -->

            <!-- Customers Card -->
            <div class="col-xxl-4 col-xl-12">

              <div class="card info-card customers-card">

              

                <div class="card-body">
                  <h5 class="card-title">Total Devices </h5>

                  <div class="d-flex align-items-center">
                    <div class="card-icon rounded-circle d-flex align-items-center justify-content-center" style="background : yellow;color: black;">
                      <i class="bi bi-speedometer2"></i>
                    </div>
                    <div class="ps-3">
                      <h6 >
                   


                      4



                      </h6>
                    
                    </div>
                  </div>

                </div>
              </div>

            </div><!-- End Customers Card -->


          

            <!-- Reports -->
            <div class="col-12">
              <div class="card">

               

                <div class="card-body">
                  <h5 class="card-title">Reports </h5>

                  <!-- statistics -->
                 
                  <canvas id="stakedBarChart" style="max-height: 400px;"></canvas>
                  <script>
  let energyData = [0, 0, 0, 0]; // Equivalent to previous pieArray (Kw)
  let ampData = [0, 0, 0, 0];    // Equivalent to previous lineArray (Amps)
  let chartInstance;

  function renderChart() {
    const ctx = document.querySelector('#stakedBarChart').getContext('2d');

    const chartData = {
      labels: ['LED', 'LCD', 'Pump', 'Fan'],
      datasets: [
        {
          label: 'Kw',
          data: energyData,
          backgroundColor: 'rgb(255, 99, 132)',
        },
        {
          label: 'Amps',
          data: ampData,
          backgroundColor: 'rgb(75, 192, 192)',
        }
      ]
    };

    const options = {
      plugins: {
        title: {
          display: true,
          text: 'Energy Consumption Summary'
        }
      },
      responsive: true,
      scales: {
        x: { stacked: true },
        y: { stacked: true }
      }
    };

    if (chartInstance) {
      chartInstance.data.datasets[0].data = energyData;
      chartInstance.data.datasets[1].data = ampData;
      chartInstance.update();
    } else {
      chartInstance = new Chart(ctx, {
        type: 'bar',
        data: chartData,
        options: options
      });
    }
  }

  function fetchAndUpdate() {
    fetch(`${baseUrl}/sensors.php`)
      .then(response => response.json())
      .then(data => {
        if (data.error) {
          console.error(data.error);
          return;
        }

        const amps = [
          Number(data.led),
          Number(data.lcd),
          Number(data.pump),
          Number(data.fan)
        ];

        const kw = amps.map(val => val * 3); // Example multiplier

        const dataChanged = amps.some((val, idx) => val !== ampData[idx]);

        if (dataChanged) {
          ampData = amps;
          energyData = kw;

          renderChart();

          // Update UI text values
          document.getElementById("theled").textContent = ampData[0] + "A";
          document.getElementById("thelcd").textContent = ampData[1] + "A";
          document.getElementById("thepump").textContent = ampData[2] + "A";
          document.getElementById("thefan").textContent = ampData[3] + "A";
        }
      })
      .catch(error => {
        console.error('Error fetching data:', error);
      });
  }

  document.addEventListener("DOMContentLoaded", () => {
    renderChart();               // draw once
    fetchAndUpdate();            // fetch once
    setInterval(fetchAndUpdate, 1000); // every second
  });
</script>

                  <!-- End statistics -->

                </div>

              </div>
            </div><!-- End Reports -->

            <!-- Summary -->
            <div class="col-12">
              <div class="card recent-sales overflow-auto">

               

                <div class="card-body">
                  <h5 class="card-title">Summary <span>| Today</span></h5>

                  <table class="table table-borderless datatable">
                    <thead>
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col">Device</th>
                        <th scope="col">Consumption</th>
                       
                        <th scope="col">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                    
                      <tr>
                        <th scope="row"><a href="#">#1</a></th>
                        <td>led</td>
                        <td><a id = "theled" href="#" class="text-primar"></a></td>
                      
                        <td>
                         
                            <input type="text"  name="gadget" id = "gadget1" value = "led" hidden>
                            <input type="text"  name="state" id="state1" value = "0" hidden>
                            <button id= "btn1" class="btn btn-success" type="submit">on</button>
                   
                          </td>
                      
                      </tr>

                       
                      <tr>
                        <th scope="row"><a href="#">#2</a></th>
                        <td>lcd</td>
                        <td><a id = "thelcd" href="#" class="text-primar">5kw</a></td>
                      
                        <td>

                        <input type="text"  name="gadget2" id = "gadget2" value = "lcd" hidden>
                            <input type="text"  name="state2" id="state2" value = "0" hidden>
                            <button id= "btn2" class="btn btn-success" type="submit">on</button>
                        </td>
                      </tr>

                         
                      <tr>
                        <th scope="row"><a href="#">#3</a></th>
                        <td>pump</td>
                        <td><a id = "thepump" href="#" class="text-primar">9kw</a></td>
                       
                        <td>
                          
                        <input type="text"  name="gadget3" id = "gadget3" value = "pump" hidden>
                            <input type="text"  name="state3" id="state3" value = "0" hidden>
                            <button id= "btn3" class="btn btn-success" type="submit">on</button>
                      
                      </td>
                      </tr>

                      <tr>
                        <th scope="row"><a href="#">#4</a></th>
                        <td>fan</td>
                        <td><a id = "thefan" href="#" class="text-primar"></a></td>
                       
                        <td>
                          
                        <input type="text"  name="gadget4" id = "gadget4" value = "fan" hidden>
                            <input type="text"  name="state4" id="state4" value = "0" hidden>
                            <button id= "btn4" class="btn btn-success" type="submit">on</button>
                      
                      </td>
                      </tr>
                    
                    </tbody>
                  </table>

                </div>

              </div>
            </div><!-- End Summary -->

           

          </div>
        </div><!-- End Left side columns -->

        <!-- Right side columns -->
        <div class="col-lg-4">
   <div style="display: flex;flex-direction: row; flex-wrap: wrap; justify-content: space-around;">

   
          <!-- Working Devices -->
          <div class="col-xxl-5 col-xl-12">

            <div class="card info-card customers-card">

            

              <div class="card-body">
                <h5 class="card-title">Working Devices <span>| Today</span> </h5>

                <div class="d-flex align-items-center">
                  <div class="card-icon rounded-circle d-flex align-items-center justify-content-center" style="background : orange;color: #12475d;">
                    <i class="bi bi-plug-fill"></i>
                  </div>
                  <div class="ps-3">
                    <h6 id = "devices">
<script>
  let sure = 0;
                      function calcDevices(total,lcd,led,pump,fan) {

                        
                        let off = 0;

                      if ( Number(lcd) == off) {

                        total--;
                        
                      } if (Number(led) == off) {
                        total--;
                      } if (Number(pump) == off) {
                        total --;
                        
                      }  if(Number(fan) == off) {
                        total--;
                      }

                        return  Number(total) ;
                        
                      }
                      function fetchTemperature() {
                          fetch(`${baseUrl}/sensors.php`)  // Adjust the path if necessary
                              .then(response => response.json())
                              .then(data => {
                                  if (data.temperature !== null) {
                                   sure = calcDevices(4,data.lcd,data.led,data.pump,data.fan);
                                      document.getElementById('devices').textContent = ` ${calcDevices(4,data.lcd,data.led,data.pump,data.fan) } `;
                                  } else {
                                      document.getElementById('temperature').textContent = 'No data available';
                                  }
                              })
                              .catch(error => {
                                  console.error('Error fetching temperature:', error);
                                  document.getElementById('temperature').textContent = 'Error retrieving data';
                              });
                      }
                  
                      // Fetch temperature every second (1000 ms)
                      setInterval(fetchTemperature, 1000);
                  
                      // Initial fetch on page load
                      fetchTemperature();
                  </script>


                    </h6>
                  
                  </div>
                </div>

              </div>
            </div>

          </div>

       <!-- End Working Devices -->

       <!-- most power consuming  -->

       <div class="col-xxl-6 col-xl-12">

        <div class="card info-card customers-card">

        

          <div class="card-body">
            <h5 class="card-title">most power consuming <span>| Today</span> </h5>

            <div class="d-flex align-items-center">
              <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                <i class="bi bi-battery-charging"></i>
              </div>
              <div class="ps-3">
                <h6 id="power">
                </h6>
                   
                  <script>
    let last ="";
                    function calcGadget(v,lcd,led,pump,fan) {

                      let max = Number(lcd);
                     

 if (Number(led) > max) {

  max = Number(led)
   

} if (Number(pump) > max) {
  max = Number(pump)
  
  
}  if(Number(fan) > max) {
  max = Number(fan)
   
}

let total = max * v;
  return  total + "kw"; 
                      
                    }


                       function calcUsage(v,lcd,led,pump,fan) {

                      let max = 0;
                     
   let gadget = "";
 if (Number(led) > max) {


     gadget = "led"

} if (Number(pump) > max) {
 
     gadget = "pump"
  
}  if(Number(fan) > max) {
 
     gadget = "fan"
}
if(Number(lcd) > max) {
 
 gadget = "lcd"
}



  return gadget; 
                      
                    }

                    function fetchTemperature() {
                        fetch(`${baseUrl}/sensors.php`)  // Adjust the path if necessary
                            .then(response => response.json())
                            .then(data => {
                                if (data.temperature !== null) {
                                  last = calcUsage(3,data.lcd,data.led,data.pump,data.fan);
                                    document.getElementById('power').textContent = ` ${calcUsage(3,data.lcd,data.led,data.pump,data.fan) } `;
                                    document.getElementById('gadget').textContent = ` ${calcGadget(3,data.lcd,data.led,data.pump,data.fan) } `;

                                } else {
                                    document.getElementById('temperature').textContent = 'No data available';
                                }
                            })
                            .catch(error => {
                                console.error('Error fetching temperature:', error);
                                document.getElementById('temperature').textContent = 'Error retrieving data';
                            });
                    }
                
                    // Fetch temperature every second (1000 ms)
                    setInterval(fetchTemperature, 1000);
                
                    // Initial fetch on page load
                    fetchTemperature();
                </script>
                  
                  
                  
                
                <span id="gadget" class="text-success small pt-1 fw-bold"> </span>

              
              </div>
            </div>

          </div>
        </div>

      </div>
      </div>

       <!-- end most power consuming -->

          <!-- consumption Report -->
          <div class="card">
          

            <div class="card-body pb-0">
              <h5 class="card-title">Wattage Report  (kw)<span>| Today</span></h5>

              <div id="pieChart"></div>
              <script>
  let kwSeries = [0, 0, 0, 0];      // Equivalent to pieArray, stores calculated Kw
  let ampReadings = [0, 0, 0, 0];   // Equivalent to lineArray, stores raw sensor data
  let pieChartInstance = null;

  function updateEnergyPieChart() {
    fetch(`${baseUrl}/sensors.php`)
      .then(response => response.json())
      .then(data => {
        if (data && data.led !== undefined) {
          const factor = 3;

          const newAmps = [
            Number(data.led),
            Number(data.lcd),
            Number(data.pump),
            Number(data.fan)
          ];

          const newKw = newAmps.map(val => val * factor);

          const changed = newAmps.some((val, i) => val !== ampReadings[i]);

          if (changed) {
            ampReadings = newAmps;
            kwSeries = newKw;

            // Update UI text
           

            // Update chart if already rendered
            if (pieChartInstance) {
              pieChartInstance.updateSeries(kwSeries);
            }
          }
        } else {
          document.getElementById('temperature').textContent = 'No data available';
        }
      })
      .catch(error => {
        console.error('Error fetching energy data:', error);
        document.getElementById('temperature').textContent = 'Error retrieving data';
      });
  }

  document.addEventListener("DOMContentLoaded", () => {
    // Initial fetch
    updateEnergyPieChart();

    // Start real-time updates
    setInterval(updateEnergyPieChart, 1000);

    // Initialize pie chart once
    pieChartInstance = new ApexCharts(document.querySelector("#pieChart"), {
      series: kwSeries,
      chart: {
        height: 350,
        type: 'pie',
        toolbar: { show: true }
      },
      labels: ['led', 'lcd', 'pump', 'fan']
    });

    pieChartInstance.render();
  });
</script>


            </div>
          </div><!-- End consumption Report -->

          <!-- Electric Current -->
          <div class="card">
          

            <div class="card-body pb-0">
              <h5 class="card-title">Electric Current <span>| Today</span></h5>
              
              <!-- up time -->
              <div id="lineChart"></div>

              <script>
  let ampDataSeries = [0, 0, 0, 0]; // Replaces lineArray
  let lineChartInstance = null;

  function updateEnergyLineChart() {
    fetch(`${baseUrl}/sensors.php`)
      .then(response => response.json())
      .then(data => {
        if (data && data.led !== undefined) {
          const newAmps = [
            Number(data.led),
            Number(data.lcd),
            Number(data.pump),
            Number(data.fan)
          ];

          const changed = newAmps.some((val, i) => val !== ampDataSeries[i]);

          if (changed) {
            ampDataSeries = newAmps;

            // Update chart if it's already created
            if (lineChartInstance) {
              lineChartInstance.updateSeries([{
                name: "Amps",
                data: ampDataSeries
              }]);
            }

            // Optionally update text values elsewhere
          
          }
        } else {
          document.getElementById('temperature').textContent = 'No data available';
        }
      })
      .catch(error => {
        console.error('Error fetching data:', error);
        document.getElementById('temperature').textContent = 'Error retrieving data';
      });
  }

  document.addEventListener("DOMContentLoaded", () => {
    // Initialize the line chart
    lineChartInstance = new ApexCharts(document.querySelector("#lineChart"), {
      series: [{
        name: "Amps",
        data: ampDataSeries
      }],
      chart: {
        height: 350,
        type: 'line',
        zoom: { enabled: false }
      },
      dataLabels: { enabled: false },
      stroke: { curve: 'straight' },
      grid: {
        row: {
          colors: ['#f3f3f3', 'transparent'],
          opacity: 0.5
        }
      },
      xaxis: {
        categories: ['led', 'lcd', 'pump', 'fan']
      }
    });

    lineChartInstance.render();

    // Initial fetch and auto-update every second
    updateEnergyLineChart();
    setInterval(updateEnergyLineChart, 1000);
  });
</script>

    <!--end  up time -->
            </div>
          </div><!-- End Electric Current -->

     

        </div><!-- End Right side columns -->

      </div>
    </section>

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <?php
  include ("footer.php");
  ?><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/apexcharts/apexcharts.min.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/chart.js/chart.umd.js"></script>
  <script src="assets/vendor/echarts/echarts.min.js"></script>
  <script src="assets/vendor/quill/quill.js"></script>
  <script src="assets/vendor/simple-datatables/simple-datatables.js"></script>
  <script src="assets/vendor/tinymce/tinymce.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>


     
 



<script>
  
  document.addEventListener('DOMContentLoaded', function () {

// Function to request permission for notifications and store it in localStorage
function requestNotificationPermission() {
    // Check if permission has already been granted
    if (localStorage.getItem('notification_permission') !== 'granted') {
        if (Notification.permission === "default") {
            Notification.requestPermission().then(permission => {
                if (permission === "granted") {
                    // Store permission status in localStorage
                    localStorage.setItem('notification_permission', 'granted');
                    console.log("Permission granted for notifications.");
                } else {
                    // Store permission status in localStorage if denied
                    localStorage.setItem('notification_permission', 'denied');
                    console.log("Permission denied for notifications.");
                }
            });
        }
    } else {
        console.log("Permission has already been granted.");
    }
}

// Show a notification
function showNotification(title, body) {
    if (Notification.permission === "granted") {
        const notification = new Notification(title, {
            body: body,
            icon: `${baseUrl}/assets/img/logo.png`, // Optional: Add an icon for the notification
        });

        notification.onclick = () => {
            console.log("Notification clicked!");
            window.location.href = `http://localhost/energy/dashboard.php`; // Redirect on click
        };
    } else {
        console.log("Notifications are not allowed.");
    }
}

// Request permission on page load
requestNotificationPermission();



function detect() {
let answer;
  if(sure == 0){

    
     answer = "none of your devices are running";

 }else{
  answer = sure + " devices out of 4 are running";
 }
  return answer;
}

function detectLast() {
let answer;
  if(last == ""){

    
     answer = "none of your devices are running";

 }else{
  answer = `${calcUsage(3,glcd,gled,gpump,gfan)} is consumping a  lot of power about  ${calcGadget(3,glcd,gled,gpump,gfan)} `;
 }
  return answer;
}
function myTimes(){
setTimeout(() => {



 showNotification("electic consumption alert",  detect())
  

   }, 5000); 


setTimeout(() => {
     
  showNotification("electic consumption alert",  detectLast())

    
     
  }, 8000); 



  setTimeout(() => {
     
     showNotification("electic consumption alert",  detectLast())
   
       
        
     }, 90000); 

     setTimeout(() => {
     
     showNotification("electic consumption alert",  detectLast())
   
       
        
     }, 180000); 


     setTimeout(() => {



showNotification("electic consumption alert",  detect())
 

  }, 360000); 
   

}

myTimes();

});




  
  </script>

<script src = "gadgets.js"> </script>


  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

  

</body>

</html>