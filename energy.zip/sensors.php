<?php
// Set headers for CORS and JSON content
header('Access-Control-Allow-Origin: *');  // Allows all domains, modify as needed
header('Content-Type: application/json');  // Ensures the response is in JSON format

// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "esp8266_data";  // Replace with your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to get the latest temperature from the database
$sql = "SELECT water_level,pump,lcd,led,fan FROM sensor_data ORDER BY id DESC LIMIT 1"; // Adjust based on your DB
$result = $conn->query($sql);



// Check if there's any result
if ($result->num_rows > 0) {
    // Fetch the row
    $row = $result->fetch_assoc();

    $water_level = $row['water_level'];
    $pump = $row['pump'];
    $lcd = $row['lcd'];
    $led = $row['led'];
    $fan = $row['fan'];

} else {
    $temperature = "No data available";  // In case there is no data
}

// Close the connection
$conn->close();

// Return the temperature as JSON
echo json_encode(['water_level' => $water_level,
'pump' => $pump,
'lcd' => $lcd,
'led' => $led,
'fan' => $fan,



]);

?>
