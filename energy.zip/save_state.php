<?php


// Database connection credentials
$servername = "localhost";  // Database server (usually localhost)
$username = "root";         // Database username
$password = "";             // Database password
$dbname = "esp8266_data";  // Your database name

// Create a database connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check if the connection was successful
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


// Check if the form data is set before accessing it
if (isset($_POST['gadget']) && isset($_POST['state'])) {
    $gadget = $_POST['gadget'];  // "led" (value from the form)
    $state = $_POST['state'];    // "0" (value from the form)
    
    // Prepare the SQL query to update the user's is_gadget and state
    $sql = "UPDATE toggle_states SET state = ? WHERE gadget = ?";

    // Prepare the SQL statement
    $stmt = $conn->prepare($sql);

    // Check if the statement was prepared successfully
    if ($stmt === false) {
        die("Error preparing the SQL query: " . $conn->error);
    }

    // Bind the parameters to the query and execute
    $is_gadget = 1;  // Assuming 1 means it is a gadget
    $stmt->bind_param("is",  $state, $gadget);  // "i" for integer, "s" for string

    // Execute the query
    if ($stmt->execute()) {
        echo "Record updated successfully!";
    } else {
        echo "Error updating record: " . $stmt->error;
    }

    // Close the prepared statement and database connection
    $stmt->close();
} else {
    echo "Error: gadget or state is not set.";
}

// Close the connection
$conn->close();
?>
