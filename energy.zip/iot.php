<?php
// MySQL database credentials
$servername = "localhost";
$username = "root";  // Use your database username
$password = "";      // Use your database password
$dbname = "esp8266_data"; // Use your database name

// Create a connection to MySQL
$conn = new mysqli($servername, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

// Get the temperature and humidity from the URL parameters
if(isset($_GET['water_level']) && isset($_GET['pump']) && isset($_GET['lcd']) && isset($_GET['led']) && isset($_GET['fan'])) {
   
    $water_level = $_GET['water_level'];
    $pump = $_GET['pump'];
    $lcd = $_GET['lcd'];
    $led = $_GET['led'];
    $fan = $_GET['fan'];


    echo  "the temp is :".$pump;

    // Prepare the SQL query to insert data into the table
    $sql = "INSERT INTO sensor_data (water_level, pump,lcd,led,fan) VALUES ('$water_level', '$pump','$lcd','$led','$fan')";

    // Execute the query
    if ($conn->query($sql) === TRUE) {
        echo "Data inserted successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
} else {
    echo "Missing temperature or humidity data.";
}

// Close the connection
$conn->close();
?>
