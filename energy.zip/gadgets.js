function gadgets(info,index,states,btn){

    let state = info[index].state
    let state1 = document.getElementById(`${states}`);
    let btn1 = document.getElementById(`${btn}`);
    
    state1.value = state == 0 ? 1 : 0;

    if (state == 0) {

      if (info[index].gadget == "pump" ){
        
        btn1.style = "background:#198754";
       btn1.textContent = "on";}

       if(info[index].gadget == "fan"){

        btn1.style = "background:#198754";
       btn1.textContent = "on";

       }if( info[index].gadget == "lcd"){

        btn1.style = "background:#198754";
        btn1.textContent = "on";

       }

      if( info[index].gadget == "led"){

        btn1.style = "background:red";
        btn1.textContent = "off";
       }
          

      
     
    } else{

      if (info[index].gadget == "pump" ){
        
        btn1.style = "background:red";
       btn1.textContent = "off";}

       if(info[index].gadget == "fan"){

        btn1.style = "background:red";
       btn1.textContent = "off";

       }if( info[index].gadget == "lcd"){

        btn1.style = "background:red";
        btn1.textContent = "off";

       



      }if( info[index].gadget == "led"){

       btn1.style = "background:#198754";
       btn1.textContent = "on";
      }
    }
}

function fetchG1() {
    fetch('http://localhost/energy/toggle.php')  // Adjust the path if necessary
        .then(response => response.json())
        .then(data => {
           
              for (let i = 0; i < data.length; i++) {
                
                if (data[i].gadget == "led") {

                    gadgets(data,i,"state1","btn1");

                }
               else if (data[i].gadget == "lcd") {
                    gadgets(data,i,"state2","btn2");

                    
                }
               else if (data[i].gadget == "pump") {
                    gadgets(data,i,"state3","btn3");

                    
                } if (data[i].gadget == "fan") {
                    gadgets(data,i,"state4","btn4");

                    
                }
                
              }
              
            
        })
        .catch(error => {
            console.error('Error fetching temperature:', error);
            
        });
}




document.addEventListener('DOMContentLoaded', function() {
    const submitBtn = document.getElementById('btn1');
    submitBtn.addEventListener('click', function(e) {
      e.preventDefault();
      const state = document.getElementById('state1').value;
      const gadget = document.getElementById('gadget1').value;
  
      const xhr = new XMLHttpRequest();
      xhr.open('POST', 'dashboard.php', true);
      xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
      xhr.onload = function() {
        if (xhr.status === 200) {
          fetchG1();
        }
      };
      xhr.send(`state=${state}&gadget=${gadget}`);
    });
  });


  document.addEventListener('DOMContentLoaded', function() {
    const submitBtn = document.getElementById('btn2');
    submitBtn.addEventListener('click', function(e) {
      e.preventDefault();
      const state = document.getElementById('state2').value;
      const gadget = document.getElementById('gadget2').value;
  
      const xhr = new XMLHttpRequest();
      xhr.open('POST', 'dashboard.php', true);
      xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
      xhr.onload = function() {
        if (xhr.status === 200) {
          fetchG1();
        }
      };
      xhr.send(`state=${state}&gadget=${gadget}`);
    });
  });


  document.addEventListener('DOMContentLoaded', function() {
    const submitBtn = document.getElementById('btn3');
    submitBtn.addEventListener('click', function(e) {
      e.preventDefault();
      const state = document.getElementById('state3').value;
      const gadget = document.getElementById('gadget3').value;
  
      const xhr = new XMLHttpRequest();
      xhr.open('POST', 'dashboard.php', true);
      xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
      xhr.onload = function() {
        if (xhr.status === 200) {
          fetchG1();
        }
      };
      xhr.send(`state=${state}&gadget=${gadget}`);
    });
  });


  document.addEventListener('DOMContentLoaded', function() {
    const submitBtn = document.getElementById('btn4');
    submitBtn.addEventListener('click', function(e) {
      e.preventDefault();
      const state = document.getElementById('state4').value;
      const gadget = document.getElementById('gadget4').value;
  
      const xhr = new XMLHttpRequest();
      xhr.open('POST', 'dashboard.php', true);
      xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
      xhr.onload = function() {
        if (xhr.status === 200) {
          fetchG1();
        }
      };
      xhr.send(`state=${state}&gadget=${gadget}`);
    });
  });

