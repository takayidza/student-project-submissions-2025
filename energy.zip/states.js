document.addEventListener('DOMContentLoaded', function() {

    function devices(info,index,states,btn){

        let state = info[index].state
        let state1 = document.getElementById(`${states}`);
        let btn1 = document.getElementById(`${btn}`);
        
        state1.value = state;
    
        if (state == 0) {

          if (info[index].gadget == "pump" ){
            
            btn1.style = "background:#198754";
           btn1.textContent = "on";}
    
           if(info[index].gadget == "fan"){
    
            btn1.style = "background:#198754";
           btn1.textContent = "on";
    
           }if( info[index].gadget == "lcd"){
    
            btn1.style = "background:#198754";
            btn1.textContent = "on";
    
           }
    
          if( info[index].gadget == "led"){
    
            btn1.style = "background:red";
            btn1.textContent = "off";
           }
              
    
          
         
        } else{
    
          if (info[index].gadget == "pump" ){
            
            btn1.style = "background:red";
           btn1.textContent = "off";}
    
           if(info[index].gadget == "fan"){
    
            btn1.style = "background:red";
           btn1.textContent = "off";
    
           }if( info[index].gadget == "lcd"){
    
            btn1.style = "background:red";
            btn1.textContent = "off";
    
           
    
    
    
          }if( info[index].gadget == "led"){
    
           btn1.style = "background:#198754";
           btn1.textContent = "on";
          }
        }
    }


    function fetchDevices() {
        fetch('http://localhost/energy/toggle.php')  // Adjust the path if necessary
            .then(response => response.json())
            .then(data => {
               
                  for (let i = 0; i < data.length; i++) {
                    
                    if (data[i].gadget == "led") {
    
                        devices(data,i,"state1","btn1");
    
                    }
                   else if (data[i].gadget == "lcd") {
                        devices(data,i,"state2","btn2");
    
                        
                    }
                   else if (data[i].gadget == "pump") {
                        devices(data,i,"state3","btn3");
    
                        
                    } if (data[i].gadget == "fan") {
                        devices(data,i,"state4","btn4");
    
                        
                    }
                    
                  }
                  
                
            })
            .catch(error => {
                console.error('Error fetching temperature:', error);
                
            });
    }

      // Fetch temperature every second (1000 ms)
    
                
      // Initial fetch on page load
      fetchDevices();
    




});