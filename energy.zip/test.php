
<input type="text" id="state" name="state" placeholder="Enter state">
<input type="text" id="gadget" name="gadget" placeholder="Enter gadget">
<button id="submit-btn">Submit</button>

<div id="response"></div>
```

JavaScript
```
document.addEventListener('DOMContentLoaded', function() {
  const submitBtn = document.getElementById('submit-btn');
  submitBtn.addEventListener('click', function(e) {
    e.preventDefault();
    const state = document.getElementById('state').value;
    const gadget = document.getElementById('gadget').value;

    const xhr = new XMLHttpRequest();
    xhr.open('POST', 'same_file.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onload = function() {
      if (xhr.status === 200) {
        document.getElementById('response').innerHTML = xhr.responseText;
      }
    };
    xhr.send(`state=${state}&gadget=${gadget}`);
  });
});
```

PHP (same_file.php)
```
<?php
  // connect to database
  $conn = mysqli_connect("localhost", "username", "password", "database");

  if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
  }

  // check if form data is submitted
  if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $state = $_POST['state'];
    $gadget = $_POST['gadget'];

    // insert data into database
    $sql = "INSERT INTO your_table (state, gadget) VALUES ('$state', '$gadget')";
    if (mysqli_query($conn, $sql)) {
      echo "Data inserted successfully!";
    } else {
      echo "Error inserting data: " . mysqli_error($conn);
    }
  }

  // close database connection
  mysqli_close($conn);
?>
```

Note:

- The JavaScript code uses the `XMLHttpRequest` object to send a POST request to the PHP file.
- The PHP code remains the same as in the previous example.