<?php
$servername = "localhost";  // Your MySQL server address (usually localhost)
$username = "root";     // Your MySQL username
$password = "";     // Your MySQL password
$dbname = "esp8266_data";         // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Query to fetch data from the 'toggle_states' table
$sql = "SELECT id, gadget, state FROM toggle_states";  // Adjust this query to suit your table structure
$result = $conn->query($sql);

$response = array();  // Initialize the response array

if ($result->num_rows > 0) {
    // Output the data as a JSON response
    while ($row = $result->fetch_assoc()) {
        $response[] = $row;  // Append each row of data to the response array
    }
} else {
    $response[] = array("error" => "No data found");  // In case of no data
}

// Close the connection
$conn->close();

// Set content type to JSON
header('Content-Type: application/json');

// Output the JSON response
echo json_encode($response);
?>
